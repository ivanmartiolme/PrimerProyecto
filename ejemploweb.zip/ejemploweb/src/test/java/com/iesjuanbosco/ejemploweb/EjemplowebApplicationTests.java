package com.iesjuanbosco.ejemploweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
